#pragma once
#include"Person.h"
#include"resourse.h"
class Booklist {
	Book data;
	Book* next;
};

class Eassylist {
	Eassy data;
	Eassy* next;
};


class Userlist {
	User data;
	User* next;
};