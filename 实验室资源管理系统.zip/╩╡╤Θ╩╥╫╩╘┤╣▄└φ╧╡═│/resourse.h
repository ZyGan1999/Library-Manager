#pragma once
#include<iostream>
#include<string>

using namespace std;
class Resourse {
public:
	Resourse();
	int getID();
	string getName();
	void checkIN();
	void checkOUT();

protected:
	int ID; string name; bool isIN; static int _K;
};


class Book :public Resourse {
public:
	Book(const string&,const string&,const string&);
	string getAuthorName();
	string getPublisherName();
	bool operator == (const Book& rhs) const {
		return ID == rhs.ID;
	}
private:
	string AuthorName; string PublisherName;
};

class Eassy :public Resourse {
public:
	Eassy(const string&,const string&);
	string getAuthorName();
	bool operator == (const Eassy& rhs) const
	{
		return ID == rhs.ID;
	}
private:
	string AuthorName; 
};