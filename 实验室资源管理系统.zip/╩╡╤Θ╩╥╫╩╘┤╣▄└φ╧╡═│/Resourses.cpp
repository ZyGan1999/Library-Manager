#include"resourse.h"
int Resourse::_K = 1;
Book::Book(const string& bookname, const string& authorname, const string& publishername) :Resourse::Resourse() {
	name = bookname;
	AuthorName = authorname;
	PublisherName = publishername;
}

Eassy::Eassy(const string& eassyname, const string& authorname) :Resourse::Resourse() {
	name = eassyname;
	AuthorName = authorname;
}

Resourse::Resourse() {
	isIN = true;
	ID = _K++;
	name = "None";
}

int Resourse::getID() {
	return ID;
}

string Resourse::getName() {
	return name;
}

void Resourse::checkIN() {
	isIN = true;
}

void Resourse::checkOUT() {
	isIN = false;
}

string Book::getAuthorName()
{
	return AuthorName;
}

string Book::getPublisherName()
{
	return PublisherName;
}

string Eassy::getAuthorName() {
	return AuthorName;
}