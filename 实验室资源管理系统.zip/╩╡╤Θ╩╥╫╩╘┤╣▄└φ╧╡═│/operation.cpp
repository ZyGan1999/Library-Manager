#include "operation.h"

void operation::AddResourse(Book & book)
{
	bList.push_front(book);
}

bool operation::DeleteResourse_B(int id)
{
	for (std::list<Book>::iterator i = bList.begin(); i != bList.end(); ++i)
	{
		if ((*i).getID() == id)
		{
			bList.remove(*i);
			return true;
		}
	}
	return false;
}

void operation::AddResourse(Eassy & eassy)
{
	eList.push_front(eassy);
}

bool operation::DeleteResourse_E(int id)
{
	for (std::list<Eassy>::iterator i = eList.begin(); i != eList.end(); ++i) {
		if (i->getID() == id) {
			eList.remove(*i);
			return true;
		}
	}
	return false;
}

void operation::AddPerson(User &us)
{
	uList.push_front(us);
}

bool operation::DeletePerson(const std::string & name)
{
	for (std::list<User>::iterator i = uList.begin(); i != uList.end(); ++i) {
		if (i->getName() == name) {
			uList.remove(*i);
			return true;
		}
	}
	return false;
}


bool operation::QueryBook(const std::string& name)
{
	bool ret = false;

	for (std::list<Book>::iterator i = bList.begin(); i != bList.end(); ++i) {
		if ((*i).getName().find(name, 0) != std::string::npos)
		{
			ret = true;
			std::cout << i->getID() << ' ' << i->getName() << ' ' << i->getAuthorName() << std::endl;
		}
	}
	return ret;
}

bool operation::QueryEassy(const std::string &name)
{
	bool ret = false;

	for (std::list<Eassy>::iterator i = eList.begin(); i != eList.end(); ++i) {
		if (i->getName().find(name, 0) != std::string::npos) {
			ret = true;
			std::cout << i->getID() << ' ' << i->getName() << ' ' << i->getAuthorName() << std::endl;
		}
	}
	return ret;
}

bool operation::RentBook(int id)
{
	for (std::list<Book>::iterator i = bList.begin(); i != bList.end(); ++i) {
		if (i->getID() == id) {
			i->checkOUT();
			return true;
		}
	}
	return false;
}

bool operation::RentEassy(int id)
{
	for (std::list<Eassy>::iterator i = eList.begin(); i != eList.end(); ++i) {
		if (i->getID() == id) {
			i->checkOUT();
			return true;
		}
	}
	return false;
}

bool operation::BackBook(int id)
{
	for (std::list<Book>::iterator i = bList.begin(); i != bList.end(); ++i) {
		if (i->getID() == id) {
			i->checkIN();
			return true;
		}
	}
	return false;
}

bool operation::BackEassy(int id)
{
	for (std::list<Eassy>::iterator i = eList.begin(); i != eList.end(); ++i) {
		if (i->getID() == id) {
			i->checkIN();
			return true;
		}
	}
	return false;
}

void operation::MENU()
{
	cout << "��ѡ��������еĲ���" << endl;
	cout << "1�������û�" << endl;
	cout << "2��ɾ���û�" << endl;
	cout << "3��������Ŀ" << endl;
	cout << "4��ɾ����Ŀ" << endl;
	cout << "5����������" << endl;
	cout << "6��ɾ������" << endl;
	cout << "7����ѯ��Դ" << endl;
	cout << "8��������Դ" << endl;
	cout << "9��ͼ����" << endl;
	cout << "10��ͼ��黹" << endl;
	cout << "11�����׽��" << endl;
	cout << "12�����׹黹" << endl;
	cout << "13�������Ķ�" << endl;
}




