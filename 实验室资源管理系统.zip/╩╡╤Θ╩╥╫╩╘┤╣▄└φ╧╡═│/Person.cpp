
#include "Person.h"

User::User(const string & _name) {
	name = _name;
	ID = k++;
}
int User::k = 1;

string User::getName() {
	return name;
}

int User::getID() {
	return ID;
}